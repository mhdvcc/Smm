import asyncio, os, json, hmac, hashlib, sqlite3, time, logging
from datetime import date
from urllib.parse import parse_qsl

import aiohttp
from aiohttp import web
from aiogram import Bot, Dispatcher, F
from aiogram.filters import CommandStart, CommandObject, Command
from aiogram.types import (InlineKeyboardMarkup, InlineKeyboardButton, WebAppInfo,
                           Message, CallbackQuery)

logging.basicConfig(level=logging.INFO)

BOT_TOKEN = os.environ["BOT_TOKEN"]
ADMIN_ID = int(os.getenv("ADMIN_ID", "0"))
SMM_API_URL = os.getenv("SMM_API_URL", "")      # provayder API manzili
SMM_API_KEY = os.getenv("SMM_API_KEY", "")      # provayder kaliti
WEBAPP_URL = os.getenv("WEBAPP_URL") or os.getenv("RENDER_EXTERNAL_URL", "")
CARD = os.getenv("CARD_NUMBER", "8600 0000 0000 0000")
CARD_OWNER = os.getenv("CARD_OWNER", "Ism Familiya")
PORT = int(os.getenv("PORT", "8080"))
REF_BONUS = 500          # taklif qilgan odamga so'm
DB_PATH = os.getenv("DB_PATH", "bot.db")

# provider_id ni o'z provayderingizdagi xizmat raqamlariga almashtiring.
# price = 1000 tasi uchun so'mdagi narx (o'zingizning ustamangiz bilan)
SERVICES = {
    "ig_like":  {"platform": "instagram", "name": "Instagram layk",      "provider_id": 1, "price": 9000,  "min": 50,  "max": 10000},
    "ig_view":  {"platform": "instagram", "name": "Instagram ko'rish",   "provider_id": 2, "price": 3000,  "min": 100, "max": 50000},
    "ig_fol":   {"platform": "instagram", "name": "Instagram obunachi",  "provider_id": 3, "price": 25000, "min": 50,  "max": 5000},
    "tt_like":  {"platform": "tiktok",    "name": "TikTok layk",         "provider_id": 4, "price": 8000,  "min": 50,  "max": 10000},
    "tt_view":  {"platform": "tiktok",    "name": "TikTok ko'rish",      "provider_id": 5, "price": 2000,  "min": 100, "max": 100000},
    "tt_fol":   {"platform": "tiktok",    "name": "TikTok obunachi",     "provider_id": 6, "price": 28000, "min": 50,  "max": 5000},
    "tg_view":  {"platform": "telegram",  "name": "Telegram ko'rish",    "provider_id": 7, "price": 1500,  "min": 100, "max": 100000},
    "tg_mem":   {"platform": "telegram",  "name": "Telegram a'zo",       "provider_id": 8, "price": 22000, "min": 50,  "max": 10000},
}
FREE_SERVICE = "tg_view"   # kunlik tekin bonus qaysi xizmat
FREE_QTY = 100

# ---------------- DB ----------------
db = sqlite3.connect(DB_PATH, check_same_thread=False)
db.row_factory = sqlite3.Row
db.executescript("""
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, name TEXT, balance INTEGER DEFAULT 0,
  last_free TEXT, ref_by INTEGER, created INTEGER);
CREATE TABLE IF NOT EXISTS orders(id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, service TEXT,
  link TEXT, qty INTEGER, cost INTEGER, provider_order TEXT, status TEXT, created INTEGER);
""")

def get_user(uid, name="", ref=None):
    u = db.execute("SELECT * FROM users WHERE id=?", (uid,)).fetchone()
    if not u:
        db.execute("INSERT INTO users(id,name,balance,ref_by,created) VALUES(?,?,0,?,?)",
                   (uid, name, ref, int(time.time())))
        if ref and ref != uid and db.execute("SELECT 1 FROM users WHERE id=?", (ref,)).fetchone():
            db.execute("UPDATE users SET balance=balance+? WHERE id=?", (REF_BONUS, ref))
        db.commit()
        u = db.execute("SELECT * FROM users WHERE id=?", (uid,)).fetchone()
    return u

def add_balance(uid, amount):
    db.execute("UPDATE users SET balance=balance+? WHERE id=?", (amount, uid)); db.commit()

# ---------------- Provayder ----------------
async def provider_add(service_key, link, qty):
    if not SMM_API_URL or not SMM_API_KEY:
        return {"order": f"demo{int(time.time())}"}      # demo rejim
    payload = {"key": SMM_API_KEY, "action": "add",
               "service": SERVICES[service_key]["provider_id"], "link": link, "quantity": qty}
    async with aiohttp.ClientSession() as s:
        async with s.post(SMM_API_URL, data=payload, timeout=aiohttp.ClientTimeout(total=25)) as r:
            return await r.json(content_type=None)

async def place_order(uid, service_key, link, qty, free=False):
    sv = SERVICES[service_key]
    cost = 0 if free else -(-sv["price"] * qty // 1000)
    u = get_user(uid)
    if u["balance"] < cost:
        return {"ok": False, "error": "Balans yetarli emas"}
    if cost: add_balance(uid, -cost)
    try:
        res = await provider_add(service_key, link, qty)
        if "order" not in res: raise RuntimeError(str(res))
    except Exception as e:
        logging.error("provider error: %s", e)
        if cost: add_balance(uid, cost)       # pulni qaytaramiz
        return {"ok": False, "error": "Xizmat hozir band, keyinroq urinib ko'ring"}
    db.execute("INSERT INTO orders(user_id,service,link,qty,cost,provider_order,status,created) VALUES(?,?,?,?,?,?,?,?)",
               (uid, service_key, link, qty, cost, str(res["order"]), "Bajarilmoqda", int(time.time())))
    db.commit()
    return {"ok": True}

# ---------------- Telegram initData tekshiruvi ----------------
def check_init(init_data):
    try:
        data = dict(parse_qsl(init_data, keep_blank_values=True))
        h = data.pop("hash", "")
        s = "\n".join(f"{k}={v}" for k, v in sorted(data.items()))
        key = hmac.new(b"WebAppData", BOT_TOKEN.encode(), hashlib.sha256).digest()
        if not hmac.compare_digest(hmac.new(key, s.encode(), hashlib.sha256).hexdigest(), h):
            return None
        return json.loads(data["user"])
    except Exception:
        return None

async def auth(request):
    body = await request.json()
    user = check_init(body.get("initData", ""))
    if not user:
        raise web.HTTPUnauthorized()
    return user, body

# ---------------- Web API ----------------
async def api_me(request):
    user, _ = await auth(request)
    u = get_user(user["id"], user.get("first_name", ""))
    rows = db.execute("SELECT * FROM orders WHERE user_id=? ORDER BY id DESC LIMIT 15", (u["id"],)).fetchall()
    me = (await bot.get_me()).username
    return web.json_response({
        "balance": u["balance"],
        "free_ready": u["last_free"] != str(date.today()),
        "free_label": f"{FREE_QTY} ta {SERVICES[FREE_SERVICE]['name'].lower()}",
        "services": [{"key": k, **v} for k, v in SERVICES.items()],
        "orders": [{"id": o["id"], "name": SERVICES[o["service"]]["name"], "qty": o["qty"],
                    "cost": o["cost"], "status": o["status"], "link": o["link"]} for o in rows],
        "ref_link": f"https://t.me/{me}?start=ref_{u['id']}",
        "ref_bonus": REF_BONUS, "card": CARD, "card_owner": CARD_OWNER,
    })

def valid_link(link):
    return isinstance(link, str) and link.startswith(("http://", "https://", "@")) and len(link) < 300

async def api_order(request):
    user, b = await auth(request)
    sk, link = b.get("service"), (b.get("link") or "").strip()
    try: qty = int(b.get("qty"))
    except Exception: return web.json_response({"ok": False, "error": "Miqdor noto'g'ri"})
    if sk not in SERVICES or not valid_link(link):
        return web.json_response({"ok": False, "error": "Havola noto'g'ri"})
    sv = SERVICES[sk]
    if not sv["min"] <= qty <= sv["max"]:
        return web.json_response({"ok": False, "error": f"Miqdor {sv['min']} dan {sv['max']} gacha"})
    get_user(user["id"], user.get("first_name", ""))
    res = await place_order(user["id"], sk, link, qty)
    return web.json_response(res)

async def api_free(request):
    user, b = await auth(request)
    link = (b.get("link") or "").strip()
    u = get_user(user["id"], user.get("first_name", ""))
    if u["last_free"] == str(date.today()):
        return web.json_response({"ok": False, "error": "Bugungi bonus olingan. Ertaga qaytib keling!"})
    if not valid_link(link):
        return web.json_response({"ok": False, "error": "Havola noto'g'ri"})
    res = await place_order(u["id"], FREE_SERVICE, link, FREE_QTY, free=True)
    if res["ok"]:
        db.execute("UPDATE users SET last_free=? WHERE id=?", (str(date.today()), u["id"])); db.commit()
    return web.json_response(res)

async def index(request):
    return web.FileResponse(os.path.join(os.path.dirname(__file__), "webapp", "index.html"))

# ---------------- Bot ----------------
bot = Bot(BOT_TOKEN)
dp = Dispatcher()

def main_kb():
    rows = [
        [InlineKeyboardButton(text="🚀 Ilovani ochish", web_app=WebAppInfo(url=WEBAPP_URL))],
        [InlineKeyboardButton(text="💰 Balans", callback_data="bal"),
         InlineKeyboardButton(text="💳 To'ldirish", callback_data="topup")],
        [InlineKeyboardButton(text="👥 Do'stlarni taklif qilish", callback_data="invite")],
        [InlineKeyboardButton(text="🆘 Yordam", callback_data="help")],
    ]
    return InlineKeyboardMarkup(inline_keyboard=rows)

@dp.message(CommandStart())
async def start(m: Message, command: CommandObject):
    ref = None
    if command.args and command.args.startswith("ref_"):
        try: ref = int(command.args[4:])
        except ValueError: pass
    get_user(m.from_user.id, m.from_user.first_name, ref)
    await m.answer(
        f"👋 Salom, <b>{m.from_user.first_name}</b>!\n\n"
        "Bu yerda Instagram, TikTok va Telegram uchun layk, ko'rish va obunachi buyurtma qilasiz.\n"
        f"🎁 Har kuni <b>tekin bonus</b>: {FREE_QTY} ta ko'rish.\n\n"
        "Boshlash uchun pastdagi tugmani bosing 👇",
        parse_mode="HTML", reply_markup=main_kb())

@dp.callback_query(F.data == "bal")
async def cb_bal(c: CallbackQuery):
    u = get_user(c.from_user.id)
    await c.answer(f"Balans: {u['balance']:,} so'm".replace(",", " "), show_alert=True)

@dp.callback_query(F.data == "topup")
async def cb_topup(c: CallbackQuery):
    await c.message.answer(
        f"💳 <b>Balansni to'ldirish</b>\n\nKarta: <code>{CARD}</code>\nEgasi: {CARD_OWNER}\n\n"
        "To'lov qilgach, <b>chek rasmini</b> shu yerga yuboring va rasm ostiga <b>summani</b> yozing "
        "(masalan: 20000). Admin tekshirib, balansingizni to'ldiradi.", parse_mode="HTML")
    await c.answer()

@dp.callback_query(F.data == "invite")
async def cb_invite(c: CallbackQuery):
    me = (await bot.get_me()).username
    await c.message.answer(
        f"👥 Havolangiz:\nhttps://t.me/{me}?start=ref_{c.from_user.id}\n\n"
        f"Har bir do'stingiz uchun <b>{REF_BONUS} so'm</b> olasiz!", parse_mode="HTML")
    await c.answer()

@dp.callback_query(F.data == "help")
async def cb_help(c: CallbackQuery):
    await c.message.answer("🆘 Savol bo'lsa shu yerga yozing, admin javob beradi.")
    await c.answer()

@dp.message(F.photo)
async def receipt(m: Message):
    cap = (m.caption or "").replace(" ", "")
    if not cap.isdigit() or int(cap) < 1000:
        return await m.answer("Chek rasmi ostiga faqat summani yozing (masalan: 20000) va qayta yuboring.")
    amount = int(cap)
    kb = InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(text="✅ Tasdiqlash", callback_data=f"ok:{m.from_user.id}:{amount}"),
        InlineKeyboardButton(text="❌ Rad etish", callback_data=f"no:{m.from_user.id}:{amount}")]])
    await bot.send_photo(ADMIN_ID, m.photo[-1].file_id,
        caption=f"💳 To'lov so'rovi\nFoydalanuvchi: {m.from_user.full_name} ({m.from_user.id})\nSumma: {amount} so'm",
        reply_markup=kb)
    await m.answer("✅ Chek adminga yuborildi. Tez orada javob beramiz.")

@dp.callback_query(F.data.regexp(r"^(ok|no):\d+:\d+$"))
async def admin_pay(c: CallbackQuery):
    if c.from_user.id != ADMIN_ID:
        return await c.answer("Ruxsat yo'q", show_alert=True)
    act, uid, amount = c.data.split(":"); uid, amount = int(uid), int(amount)
    if act == "ok":
        add_balance(uid, amount)
        await bot.send_message(uid, f"✅ Balansingiz {amount} so'mga to'ldirildi!")
        await c.message.edit_caption(caption=(c.message.caption or "") + "\n\n✅ Tasdiqlandi")
    else:
        await bot.send_message(uid, "❌ To'lov tasdiqlanmadi. Savol bo'lsa adminga yozing.")
        await c.message.edit_caption(caption=(c.message.caption or "") + "\n\n❌ Rad etildi")
    await c.answer()

@dp.message(Command("stats"))
async def stats(m: Message):
    if m.from_user.id != ADMIN_ID: return
    n = db.execute("SELECT COUNT(*) c FROM users").fetchone()["c"]
    o = db.execute("SELECT COUNT(*) c, COALESCE(SUM(cost),0) s FROM orders").fetchone()
    await m.answer(f"👤 Foydalanuvchilar: {n}\n📦 Buyurtmalar: {o['c']}\n💵 Tushum: {o['s']} so'm")

@dp.message(Command("add"))
async def admin_add(m: Message, command: CommandObject):
    if m.from_user.id != ADMIN_ID: return
    try:
        uid, amount = map(int, command.args.split())
        add_balance(uid, amount); await m.answer("Bajarildi ✅")
    except Exception:
        await m.answer("Format: /add user_id summa")

# ---------------- Ishga tushirish ----------------
async def main():
    app = web.Application()
    app.add_routes([web.get("/", index), web.get("/health", lambda r: web.Response(text="ok")),
                    web.post("/api/me", api_me), web.post("/api/order", api_order),
                    web.post("/api/free", api_free)])
    runner = web.AppRunner(app); await runner.setup()
    await web.TCPSite(runner, "0.0.0.0", PORT).start()
    await bot.delete_webhook(drop_pending_updates=True)
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())
